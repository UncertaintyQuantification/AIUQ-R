#' @importFrom stats rnorm runif qnorm optim
#' @importFrom methods setClass new show
#' @importFrom graphics lines polygon legend
#' @importFrom plot3D image2D
#' @importFrom grDevices grey
NULL
#> NULL
#' @keywords internal



